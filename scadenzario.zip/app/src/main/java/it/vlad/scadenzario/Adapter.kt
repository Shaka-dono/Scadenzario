package it.vlad.scadenzario

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter(private val onClick: (Item) -> Unit) : RecyclerView.Adapter<ItemAdapter.VH>() {

    private var data: List<Item> = emptyList()

    fun submit(list: List<Item>) {
        data = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val emoji: TextView = v.findViewById(R.id.tvEmoji)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val days: TextView = v.findViewById(R.id.tvDays)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false))

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = data[position]
        h.emoji.text = when (item.type) {
            T_SCAD -> SCAD_EMOJI[item.category.coerceIn(0, SCAD_EMOJI.size - 1)]
            T_ABB -> "🔁"
            else -> "🧾"
        }
        h.title.text = item.name

        val parts = mutableListOf<String>()
        when (item.type) {
            T_GAR -> {
                if (item.store.isNotBlank()) parts.add(item.store)
                parts.add("scade " + fmtDate(item.date))
            }
            T_ABB -> {
                if (item.cost > 0) parts.add(fmtMoney(item.cost))
                parts.add(repeatLabel(item.repeatMonths).lowercase())
                parts.add("rinnovo " + fmtDate(item.date))
            }
            else -> {
                parts.add(fmtDate(item.date))
                if (item.cost > 0) parts.add(fmtMoney(item.cost))
                if (item.repeatMonths > 0) parts.add(repeatLabel(item.repeatMonths).lowercase())
            }
        }
        h.sub.text = parts.joinToString(" · ")

        val d = item.daysLeft()
        h.days.text = daysText(d)
        h.days.setTextColor(
            when {
                d <= 7 -> Color.parseColor("#DC2626")
                d <= 30 -> Color.parseColor("#D97706")
                else -> Color.parseColor("#16A34A")
            }
        )
        h.itemView.setOnClickListener { onClick(item) }
    }
}
