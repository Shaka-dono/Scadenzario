package it.vlad.scadenzario

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.UUID

const val T_SCAD = 0
const val T_ABB = 1
const val T_GAR = 2
const val NOT_YET = 999

val SCAD_EMOJI = listOf("🚗", "🔧", "🛡️", "🛠️", "🔥", "🏛️", "📌")
val SCAD_NAMES = listOf("Bollo auto", "Revisione", "Assicurazione", "Tagliando", "Caldaia", "Tasse casa", "Altro")
val SCAD_DEFAULT_REPEAT = listOf(12, 24, 12, 12, 12, 6, 0)

val REPEAT_VALUES = listOf(0, 1, 2, 3, 6, 12, 24)
val REPEAT_LABELS = listOf("Nessuna", "Ogni mese", "Ogni 2 mesi", "Ogni 3 mesi", "Ogni 6 mesi", "Ogni anno", "Ogni 2 anni")

private val DF = DateTimeFormatter.ofPattern("dd/MM/yyyy")

fun fmtDate(d: LocalDate): String = d.format(DF)

fun fmtMoney(v: Double): String = String.format(Locale.ITALY, "%,.2f €", v)

fun repeatLabel(m: Int): String {
    val i = REPEAT_VALUES.indexOf(m)
    return REPEAT_LABELS[if (i < 0) 0 else i]
}

fun daysText(d: Long): String = when {
    d < 0 -> "scaduta da ${-d} g"
    d == 0L -> "oggi"
    d == 1L -> "domani"
    else -> "tra $d giorni"
}

data class Item(
    val id: String = UUID.randomUUID().toString(),
    var type: Int,
    var name: String,
    var category: Int = 0,
    var date: LocalDate,
    var cost: Double = 0.0,
    var repeatMonths: Int = 0,
    var store: String = "",
    var purchase: LocalDate? = null,
    var months: Int = 24,
    var notified: Int = NOT_YET
) {
    fun daysLeft(): Long = ChronoUnit.DAYS.between(LocalDate.now(), date)

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("type", type)
        .put("name", name)
        .put("category", category)
        .put("date", date.toString())
        .put("cost", cost)
        .put("repeat", repeatMonths)
        .put("store", store)
        .put("purchase", purchase?.toString() ?: JSONObject.NULL)
        .put("months", months)
        .put("notified", notified)

    companion object {
        fun fromJson(o: JSONObject): Item = Item(
            id = o.getString("id"),
            type = o.getInt("type"),
            name = o.getString("name"),
            category = o.optInt("category", 0),
            date = LocalDate.parse(o.getString("date")),
            cost = o.optDouble("cost", 0.0),
            repeatMonths = o.optInt("repeat", 0),
            store = o.optString("store", ""),
            purchase = if (o.isNull("purchase")) null else LocalDate.parse(o.getString("purchase")),
            months = o.optInt("months", 24),
            notified = o.optInt("notified", NOT_YET)
        )
    }
}

object Repo {
    private var items: MutableList<Item>? = null

    private fun file(c: Context) = File(c.filesDir, "items.json")

    @Synchronized
    fun all(c: Context): MutableList<Item> {
        items?.let { return it }
        val list = mutableListOf<Item>()
        val f = file(c)
        if (f.exists()) {
            try {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) list.add(Item.fromJson(arr.getJSONObject(i)))
            } catch (e: Exception) {
                // file illeggibile: si riparte vuoti
            }
        }
        items = list
        return list
    }

    @Synchronized
    fun save(c: Context) {
        val list = items ?: return
        val arr = JSONArray()
        for (item in list) arr.put(item.toJson())
        val tmp = File(c.filesDir, "items.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(file(c))) file(c).writeText(arr.toString())
    }

    // Gli abbonamenti si rinnovano da soli: la data avanza finche' non e' nel futuro.
    @Synchronized
    fun rollSubscriptions(c: Context) {
        val today = LocalDate.now()
        var changed = false
        for (item in all(c)) {
            if (item.type == T_ABB && item.repeatMonths > 0) {
                while (item.date.isBefore(today)) {
                    item.date = item.date.plusMonths(item.repeatMonths.toLong())
                    item.notified = NOT_YET
                    changed = true
                }
            }
        }
        if (changed) save(c)
    }
}
